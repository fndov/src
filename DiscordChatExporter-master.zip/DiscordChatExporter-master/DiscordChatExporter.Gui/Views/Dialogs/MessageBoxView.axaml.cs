﻿using DiscordChatExporter.Gui.Framework;
using DiscordChatExporter.Gui.ViewModels.Dialogs;

namespace DiscordChatExporter.Gui.Views.Dialogs;

public partial class MessageBoxView : UserControl<MessageBoxViewModel>
{
    public MessageBoxView() => InitializeComponent();
}
