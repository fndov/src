﻿namespace DiscordChatExporter.Core.Markdown;

internal enum MentionKind
{
    Everyone,
    Here,
    User,
    Channel,
    Role
}
