import requests
payload = {
    'content': "**PING** From: Archbtw.com"
}
headers = {
    "authorization": "MTIyMTIyNjk0MjY4MzE1MjU0Nw.GnLPAH.56-o6ehYd7YHLDDxQcZGW4CmkVt5rqjgKqo6Zc"
}
r = requests.post("https://discord.com/api/v9/channels/1239436153661165582/messages", data=payload, headers=headers)
