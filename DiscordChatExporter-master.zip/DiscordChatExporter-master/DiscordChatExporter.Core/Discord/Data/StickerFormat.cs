﻿namespace DiscordChatExporter.Core.Discord.Data;

public enum StickerFormat
{
    Png = 1,
    Apng = 2,
    Lottie = 3,
    Gif = 4
}
