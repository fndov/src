﻿namespace DiscordChatExporter.Core.Exporting.Filtering;

internal enum BinaryExpressionKind
{
    Or,
    And
}
