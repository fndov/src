﻿namespace DiscordChatExporter.Core.Discord.Dump;

public record DataDumpChannel(Snowflake Id, string Name);
