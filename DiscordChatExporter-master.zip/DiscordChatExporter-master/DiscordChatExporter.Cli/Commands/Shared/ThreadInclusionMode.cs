﻿namespace DiscordChatExporter.Cli.Commands.Shared;

public enum ThreadInclusionMode
{
    None,
    Active,
    All
}
