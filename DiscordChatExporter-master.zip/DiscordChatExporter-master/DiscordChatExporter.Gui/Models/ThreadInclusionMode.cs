﻿namespace DiscordChatExporter.Gui.Models;

public enum ThreadInclusionMode
{
    None,
    Active,
    All
}
